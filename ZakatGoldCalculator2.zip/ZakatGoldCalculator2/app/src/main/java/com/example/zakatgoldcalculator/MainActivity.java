package com.example.zakatgoldcalculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etWeight, etValue;
    RadioButton rbKeep, rbWear;
    Button btnCalculate;
    TextView tvTotalValue, tvPayableValue, tvTotalZakat, tvPayableWeight;;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int selected = item.getItemId();

        if (selected == R.id.menuAbout) {
            Intent intent = new Intent(MainActivity.this, Aboutactivity.class);
            startActivity(intent);
            return true;

        } else if (selected == R.id.menuCalculator) {
            Toast.makeText(this, "You are already on Calculator page", Toast.LENGTH_SHORT).show();
            return true;
        }
        else if (selected == R.id.menuShare) {

            String appUrl = "https://play.google.com/store/apps/details?id=com.example.zakatgoldcalculator";

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Zakat Gold Calculator");
            shareIntent.putExtra(Intent.EXTRA_TEXT, "Try this Zakat Calculator app:\n" + appUrl);

            startActivity(Intent.createChooser(shareIntent, "Share via"));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Zakat Calculator");

        etWeight = findViewById(R.id.etWeight);
        etValue = findViewById(R.id.etValue);
        rbKeep = findViewById(R.id.rbKeep);
        rbWear = findViewById(R.id.rbWear);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvTotalValue = findViewById(R.id.tvTotalValue);
        tvPayableValue = findViewById(R.id.tvPayableValue);
        tvTotalZakat = findViewById(R.id.tvTotalZakat);
        tvPayableWeight = findViewById(R.id.tvPayableWeight);





        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String weightStr = etWeight.getText().toString().trim();
                String valueStr = etValue.getText().toString().trim();

                if (weightStr.isEmpty() || valueStr.isEmpty()) {
                    tvTotalValue.setText("Please enter all fields!");
                    tvPayableValue.setText("-");
                    tvTotalZakat.setText("-");
                    return;
                }

                try {
                    double weight = Double.parseDouble(weightStr);
                    double valuePerGram = Double.parseDouble(valueStr);

                    double totalValue = weight * valuePerGram;

                    double threshold = rbKeep.isChecked() ? 85.0 : 200.0;

                    double payableWeight = weight - threshold;
                    double payableValue = 0;
                    double zakat = 0;

                    if (payableWeight > 0) {
                        payableValue = payableWeight * valuePerGram;
                        zakat = payableValue * 0.025; // 2.5%
                    }

                    tvTotalValue.setText(String.format("Total Gold Value: RM %.2f", totalValue));
                    tvPayableValue.setText(String.format("Zakat Payable Value: RM %.2f", payableValue));
                    tvPayableWeight.setText(String.format("Payable Weight: %.2f g", payableWeight));
                    tvTotalZakat.setText(String.format("Total Zakat (2.5%%): RM %.2f", zakat));

                } catch (NumberFormatException e) {
                    tvTotalValue.setText("Invalid input!");
                    tvPayableValue.setText("-");
                    tvTotalZakat.setText("-");
                }
            }
        });
    }
}
